import React from 'react';
import { Button } from './ui/Button';
import { ArrowDown } from 'lucide-react';

export function Hero() {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center bg-hero-pattern bg-cover bg-center bg-fixed">
      <div className="text-center px-4 space-y-8 backdrop-blur-sm bg-white/30 py-16 rounded-3xl max-w-4xl mx-4">
        <h1 className="text-6xl md:text-8xl font-display font-black text-gray-900 tracking-tight">
          林斯顿_
        </h1>
        <p className="text-xl md:text-2xl text-gray-700 font-display font-medium italic">
          产品经理，自由写手，预备役旅行者
        </p>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto font-light">
          生命本身应当以艺术品的形式存在，欢迎你与我的生命产生交互。
        </p>
        <div>
          <Button 
            size="lg" 
            onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
          >
            了解更多 <ArrowDown className="ml-2" size={20} />
          </Button>
        </div>
      </div>
    </section>
  );
}